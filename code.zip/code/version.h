#include <string.h>

const char vers_string[] = "LARVA version 1.0";
